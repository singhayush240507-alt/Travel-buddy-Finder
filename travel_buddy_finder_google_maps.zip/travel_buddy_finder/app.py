import os
from datetime import datetime, date
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import or_, UniqueConstraint
from urllib.parse import quote_plus

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-change-this-secret-before-deployment')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///' + os.path.join(BASE_DIR, 'travel_buddy_finder.db'))
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(180), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(100), default='')
    bio = db.Column(db.String(500), default='')
    interests = db.Column(db.String(300), default='')
    travel_style = db.Column(db.String(80), default='Flexible')
    budget = db.Column(db.Integer, default=15000)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def public(self):
        return {'id': self.id, 'name': self.name, 'email': self.email, 'city': self.city, 'bio': self.bio,
                'interests': [x.strip() for x in (self.interests or '').split(',') if x.strip()],
                'travel_style': self.travel_style, 'budget': self.budget}

class Trip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(140), nullable=False)
    destination = db.Column(db.String(120), nullable=False, index=True)
    start_location = db.Column(db.String(120), default='')
    start_date = db.Column(db.String(20), nullable=False)
    end_date = db.Column(db.String(20), nullable=False)
    budget = db.Column(db.Integer, default=0)
    description = db.Column(db.Text, default='')
    interests = db.Column(db.String(300), default='')
    max_members = db.Column(db.Integer, default=4)
    status = db.Column(db.String(20), default='open')
    creator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    creator = db.relationship('User', backref='created_trips')

class Membership(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    trip = db.relationship('Trip', backref='memberships')
    user = db.relationship('User', backref='memberships')
    __table_args__ = (UniqueConstraint('trip_id', 'user_id', name='uq_trip_member'),)

class Connection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sender = db.relationship('User', foreign_keys=[sender_id])
    receiver = db.relationship('User', foreign_keys=[receiver_id])
    __table_args__ = (UniqueConstraint('sender_id', 'receiver_id', name='uq_connection_pair'),)

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip.id'), nullable=False, index=True)
    added_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(30), nullable=False)
    title = db.Column(db.String(160), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    details = db.Column(db.String(400), default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    trip = db.relationship('Trip', backref='expenses')
    user = db.relationship('User')

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    body = db.Column(db.String(2000), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sender = db.relationship('User', foreign_keys=[sender_id])
    receiver = db.relationship('User', foreign_keys=[receiver_id])

class ItineraryItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip.id'), nullable=False, index=True)
    added_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    day = db.Column(db.String(20), nullable=False)
    title = db.Column(db.String(160), nullable=False)
    time = db.Column(db.String(20), default='')
    notes = db.Column(db.String(500), default='')
    cost = db.Column(db.Float, default=0)
    trip = db.relationship('Trip', backref='itinerary_items')
    user = db.relationship('User')


def current_user():
    uid = session.get('user_id')
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            if request.path.startswith('/api/'):
                return jsonify(error='Please log in first.'), 401
            flash('Please log in to continue.', 'info')
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapped

def trip_access(trip_id, user=None):
    user = user or current_user()
    trip = db.session.get(Trip, trip_id)
    if not trip or not user:
        abort(404)
    is_member = trip.creator_id == user.id or Membership.query.filter_by(trip_id=trip.id, user_id=user.id, status='accepted').first()
    if not is_member:
        abort(403)
    return trip

def expense_totals(trip):
    categories = {'Accommodation': 0, 'Transportation': 0, 'Activities': 0, 'Food': 0, 'Other': 0}
    for exp in trip.expenses:
        categories[exp.category] = categories.get(exp.category, 0) + exp.amount
    return categories

def destination_image(destination, seed=0):
    """Choose a destination-relevant photo and rotate variants between cards."""
    value = (destination or '').lower()
    groups = [
        (('ladakh','leh','pangong','nubra','spiti','manali','meghalaya','shillong','mountain','himalaya'), [
            'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1464278533981-50106e6176b1?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1454496522488-7a8e488e8606?auto=format&fit=crop&w=1200&q=85']),
        (('goa','andaman','pondicherry','beach'), [
            'https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?auto=format&fit=crop&w=1200&q=85']),
        (('kerala','alleppey','munnar','coorg'), [
            'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=1200&q=85']),
        (('jaipur','udaipur','agra','varanasi','heritage'), [
            'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1567157577867-05gb1c7d2?auto=format&fit=crop&w=1200&q=85']),
        (('rishikesh','river','rafting'), [
            'https://images.unsplash.com/photo-1530866495561-507c9faab2ed?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1437482078695-73f5ca6c96e2?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=85']),
        (('mumbai','city'), [
            'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=85',
            'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1200&q=85']),
    ]
    for keys, urls in groups:
        if any(key in value for key in keys):
            return urls[int(seed or 0) % len(urls)]
    fallback = [
        'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=85',
        'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=85',
        'https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=1200&q=85']
    return fallback[int(seed or 0) % len(fallback)]

def avatar_url(user):
    """Use a human portrait, never a destination image, for buddy cards.
    Demo names are mapped to gender-appropriate portrait sets; unknown names get a neutral avatar."""
    name = (getattr(user, 'name', '') or '').strip().split(' ')[0].lower()
    women = {'sana','riya','meera','ananya','zoya','tanya','naina','pooja'}
    men = {'aarav','kabir','dev','ishaan','arjun','vihaan','rehan','aditya'}
    female_ids = {'sana':44,'riya':47,'meera':49,'ananya':32,'zoya':68,'tanya':25,'naina':52,'pooja':56}
    male_ids = {'aarav':12,'kabir':33,'dev':15,'ishaan':18,'arjun':14,'vihaan':22,'rehan':51,'aditya':59}
    if name in women:
        ident = female_ids[name]
        return f'https://randomuser.me/api/portraits/women/{ident}.jpg'
    if name in men:
        ident = male_ids[name]
        return f'https://randomuser.me/api/portraits/men/{ident}.jpg'
    # For new accounts, use a neutral initials-style SVG data URI rather than guessing gender.
    initials = ((getattr(user, 'name', '') or 'T').strip()[:1] or 'T').upper()
    import urllib.parse
    svg = f"<svg xmlns='http://www.w3.org/2000/svg' width='128' height='128'><rect width='128' height='128' rx='64' fill='%23dbe8dd'/><text x='64' y='82' font-size='54' text-anchor='middle' fill='%231e5954' font-family='Arial'>{initials}</text></svg>"
    return 'data:image/svg+xml,' + urllib.parse.quote(svg)

@app.context_processor
def inject_globals():
    return {'logged_user': current_user(), 'money': lambda value: f'₹{float(value or 0):,.0f}', 'destination_image': destination_image, 'avatar_url': avatar_url}

@app.route('/')
def home():
    trips = Trip.query.filter_by(status='open').order_by(Trip.created_at.desc()).limit(9).all()
    return render_template('index.html', trips=trips)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name','').strip(); email = request.form.get('email','').strip().lower()
        password = request.form.get('password',''); confirm = request.form.get('confirm_password','')
        if not name or not email or len(password) < 8:
            flash('Enter your name and email, and use a password with at least 8 characters.', 'error')
        elif password != confirm:
            flash('Passwords do not match.', 'error')
        elif User.query.filter_by(email=email).first():
            flash('An account with that email already exists. Please log in.', 'error')
        else:
            user = User(name=name, email=email, password_hash=generate_password_hash(password))
            db.session.add(user); db.session.commit(); session.clear(); session['user_id'] = user.id
            flash('Welcome aboard! Complete your profile and find your people.', 'success')
            return redirect(url_for('profile'))
    return render_template('auth.html', mode='register')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower(); password = request.form.get('password','')
        user = User.query.filter_by(email=email).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash('Incorrect email or password.', 'error')
        else:
            session.clear(); session['user_id'] = user.id
            flash(f'Welcome back, {user.name.split()[0]}!', 'success')
            return redirect(url_for('dashboard'))
    return render_template('auth.html', mode='login')

@app.route('/logout', methods=['POST'])
def logout():
    session.clear(); flash('You have been logged out.', 'success'); return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    user = current_user()
    my_trips = Trip.query.filter_by(creator_id=user.id).order_by(Trip.created_at.desc()).all()
    joined = Membership.query.filter_by(user_id=user.id, status='accepted').all()
    pending = Membership.query.join(Trip).filter(Trip.creator_id==user.id, Membership.status=='pending').all()
    suggestions = Trip.query.filter(Trip.creator_id != user.id, Trip.status=='open').order_by(Trip.created_at.desc()).limit(3).all()
    return render_template('dashboard.html', user=user, my_trips=my_trips, joined=joined, pending=pending, suggestions=suggestions)

@app.route('/profile', methods=['GET','POST'])
@login_required
def profile():
    user = current_user()
    if request.method == 'POST':
        user.name=request.form.get('name','').strip() or user.name
        user.city=request.form.get('city','').strip()
        user.bio=request.form.get('bio','').strip()[:500]
        user.interests=request.form.get('interests','').strip()[:300]
        user.travel_style=request.form.get('travel_style','Flexible')
        try: user.budget=max(0, int(request.form.get('budget', 15000)))
        except ValueError: user.budget=15000
        db.session.commit(); flash('Profile saved!', 'success'); return redirect(url_for('profile'))
    return render_template('profile.html', user=user)

@app.route('/buddies')
@login_required
def buddies():
    query=User.query.filter(User.id != current_user().id)
    destination=request.args.get('destination','').strip()
    style=request.args.get('style','').strip()
    max_budget=request.args.get('max_budget','').strip()
    if style: query=query.filter(User.travel_style==style)
    if max_budget.isdigit(): query=query.filter(User.budget <= int(max_budget))
    users=query.order_by(User.created_at.desc()).all()
    cards=[]
    for u in users:
        mine={x.strip().lower() for x in current_user().interests.split(',') if x.strip()}
        theirs={x.strip().lower() for x in u.interests.split(',') if x.strip()}
        shared=mine & theirs
        score=35 + (25 if current_user().budget and abs(current_user().budget-u.budget) <= max(5000,current_user().budget*.25) else 0) + min(30, len(shared)*10) + (10 if current_user().travel_style==u.travel_style else 0)
        cards.append({'user':u,'score':min(99,score),'shared':sorted(shared)})
    if destination:
        cards=[c for c in cards if destination.lower() in (c['user'].bio+' '+c['user'].interests+' '+c['user'].city).lower()]
    return render_template('buddies.html', cards=cards, destination=destination, style=style, max_budget=max_budget)

@app.route('/maps')
def google_maps():
    """Search destinations and open map/directions links through Google Maps."""
    destination = (request.args.get('destination') or '').strip()[:180]
    start_location = (request.args.get('start_location') or '').strip()[:180]
    search_query = (request.args.get('search_query') or '').strip()[:180]
    map_query = destination or search_query or 'popular travel destinations in India'
    map_embed_url = 'https://maps.google.com/maps?q=' + quote_plus(map_query) + '&output=embed'
    places_url = 'https://www.google.com/maps/search/?api=1&query=' + quote_plus(search_query or destination or 'tourist attractions')
    directions_url = None
    if destination:
        directions_url = 'https://www.google.com/maps/dir/?api=1&destination=' + quote_plus(destination)
        if start_location:
            directions_url += '&origin=' + quote_plus(start_location)
            directions_url += '&travelmode=driving'
    return render_template('maps.html', destination=destination, start_location=start_location,
                           search_query=search_query, map_query=map_query, map_embed_url=map_embed_url,
                           places_url=places_url, directions_url=directions_url)


@app.route('/trips')
def trips():
    q=Trip.query.filter_by(status='open')
    dest=request.args.get('destination','').strip(); max_budget=request.args.get('max_budget','').strip()
    if dest: q=q.filter(Trip.destination.ilike(f'%{dest}%'))
    if max_budget.isdigit(): q=q.filter(Trip.budget <= int(max_budget))
    all_trips=q.order_by(Trip.created_at.desc()).all()
    return render_template('trips.html', trips=all_trips, destination=dest, max_budget=max_budget)

@app.route('/trips/create', methods=['GET','POST'])
@login_required
def create_trip():
    if request.method=='POST':
        title=request.form.get('title','').strip(); dest=request.form.get('destination','').strip()
        start=request.form.get('start_date',''); end=request.form.get('end_date','')
        if not title or not dest or not start or not end or end < start:
            flash('Please enter a title, destination, and valid travel dates.', 'error')
        else:
            try: budget=max(0,int(request.form.get('budget',0))); cap=min(30,max(2,int(request.form.get('max_members',4))))
            except ValueError: budget=0; cap=4
            trip=Trip(title=title,destination=dest,start_location=request.form.get('start_location','').strip(),start_date=start,end_date=end,budget=budget,description=request.form.get('description','').strip(),interests=request.form.get('interests','').strip(),max_members=cap,creator_id=current_user().id)
            db.session.add(trip); db.session.commit(); flash('Trip created! Add your planned costs in the trip workspace.', 'success'); return redirect(url_for('trip_detail', trip_id=trip.id))
    return render_template('create_trip.html')

@app.route('/trips/<int:trip_id>')
def trip_detail(trip_id):
    trip=db.session.get(Trip,trip_id)
    if not trip: abort(404)
    user=current_user(); membership=None
    if user: membership=Membership.query.filter_by(trip_id=trip.id,user_id=user.id).first()
    expenses=Expense.query.filter_by(trip_id=trip.id).order_by(Expense.created_at.desc()).all()
    categories=expense_totals(trip); total=sum(categories.values())
    items=ItineraryItem.query.filter_by(trip_id=trip.id).order_by(ItineraryItem.day,ItineraryItem.time).all()
    members=Membership.query.filter_by(trip_id=trip.id,status='accepted').all()
    pending=Membership.query.filter_by(trip_id=trip.id,status='pending').all() if user and user.id==trip.creator_id else []
    return render_template('trip_detail.html', trip=trip, membership=membership, expenses=expenses, categories=categories,total=total,items=items,members=members,pending=pending)

@app.route('/trips/<int:trip_id>/join', methods=['POST'])
@login_required
def join_trip(trip_id):
    trip=db.session.get(Trip,trip_id)
    if not trip: abort(404)
    user=current_user()
    if trip.creator_id==user.id: flash('You already organize this trip.', 'info')
    elif trip.status!='open': flash('This trip is not open for requests.', 'error')
    elif Membership.query.filter_by(trip_id=trip.id,user_id=user.id).first(): flash('You have already requested or joined this trip.', 'info')
    elif len([m for m in trip.memberships if m.status=='accepted']) >= trip.max_members-1: flash('This trip is full.', 'error')
    else: db.session.add(Membership(trip_id=trip.id,user_id=user.id,status='pending')); db.session.commit(); flash('Join request sent to the trip organiser.', 'success')
    return redirect(url_for('trip_detail',trip_id=trip.id))

@app.route('/trips/<int:trip_id>/requests/<int:request_id>/<action>', methods=['POST'])
@login_required
def manage_join(trip_id,request_id,action):
    trip=db.session.get(Trip,trip_id); req=db.session.get(Membership,request_id)
    if not trip or trip.creator_id!=current_user().id: abort(403)
    if not req or req.trip_id!=trip.id or req.status!='pending' or action not in ('accept','reject'): abort(404)
    if action=='accept' and len([m for m in trip.memberships if m.status=='accepted']) >= trip.max_members-1:
        flash('The trip has reached its member limit.', 'error')
    else: req.status='accepted' if action=='accept' else 'rejected'; db.session.commit(); flash('Request updated.', 'success')
    return redirect(url_for('trip_detail',trip_id=trip.id))

@app.route('/trips/<int:trip_id>/expenses', methods=['POST'])
@login_required
def add_expense(trip_id):
    trip=trip_access(trip_id); title=request.form.get('title','').strip(); category=request.form.get('category','Other')
    try: amount=float(request.form.get('amount',0))
    except ValueError: amount=0
    if category not in ('Accommodation','Transportation','Activities','Food','Other') or not title or amount<=0 or amount>100000000:
        flash('Enter a valid expense name, category, and amount.', 'error')
    else:
        db.session.add(Expense(trip_id=trip.id,added_by=current_user().id,category=category,title=title,amount=amount,details=request.form.get('details','').strip()[:400])); db.session.commit(); flash('Expense added to the shared budget.', 'success')
    return redirect(url_for('trip_detail',trip_id=trip.id)+'#budget')

@app.route('/trips/<int:trip_id>/expenses/<int:expense_id>/delete', methods=['POST'])
@login_required
def delete_expense(trip_id,expense_id):
    trip=trip_access(trip_id); exp=db.session.get(Expense,expense_id)
    if not exp or exp.trip_id!=trip.id: abort(404)
    if exp.added_by!=current_user().id and trip.creator_id!=current_user().id: abort(403)
    db.session.delete(exp); db.session.commit(); flash('Expense removed.', 'success'); return redirect(url_for('trip_detail',trip_id=trip.id)+'#budget')

@app.route('/trips/<int:trip_id>/expenses/<int:expense_id>/edit', methods=['POST'])
@login_required
def edit_expense(trip_id, expense_id):
    trip = trip_access(trip_id)
    exp = db.session.get(Expense, expense_id)
    if not exp or exp.trip_id != trip.id:
        abort(404)
    if exp.added_by != current_user().id and trip.creator_id != current_user().id:
        abort(403)
    title = request.form.get('title', '').strip()
    category = request.form.get('category', 'Other')
    details = request.form.get('details', '').strip()[:400]
    try:
        amount = float(request.form.get('amount', 0))
    except ValueError:
        amount = 0
    if not title or amount <= 0 or amount > 100000000 or category not in ('Accommodation','Transportation','Activities','Food','Other'):
        flash('Please enter a valid name, category and amount.', 'error')
    else:
        exp.title, exp.category, exp.amount, exp.details = title, category, amount, details
        db.session.commit()
        flash('Expense updated. Shared budget recalculated.', 'success')
    return redirect(url_for('trip_detail', trip_id=trip.id) + '#budget')

@app.route('/trips/<int:trip_id>/itinerary', methods=['POST'])
@login_required
def add_itinerary(trip_id):
    trip=trip_access(trip_id); title=request.form.get('title','').strip(); day=request.form.get('day','').strip()
    if not title or not day: flash('Add an activity and day.', 'error')
    else:
        try: cost=max(0,float(request.form.get('cost',0)))
        except ValueError: cost=0
        db.session.add(ItineraryItem(trip_id=trip.id,added_by=current_user().id,day=day,title=title,time=request.form.get('time',''),notes=request.form.get('notes','').strip()[:500],cost=cost));
        if cost>0: db.session.add(Expense(trip_id=trip.id,added_by=current_user().id,category='Activities',title=title,amount=cost,details='Added from itinerary'))
        db.session.commit(); flash('Itinerary updated.', 'success')
    return redirect(url_for('trip_detail',trip_id=trip.id)+'#itinerary')

CATALOG = {
    'stays': {
        'title': 'Stays & accommodation', 'subtitle': 'Guesthouses, hostels and stays to fit your travel style.', 'category': 'Accommodation',
        'items': [
            {'name':'Mountain View Homestay','image_url':'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?auto=format&fit=crop&w=1200&q=85','place':'Leh, Ladakh','price':1800,'unit':'per room / night','type':'Homestay','desc':'Warm local hospitality with mountain views. Sample estimate.', 'image':'photo-mountain'},
            {'name':'Pangong Lakeside Camp','image_url':'https://images.unsplash.com/photo-1504851149312-7a075b496cc7?auto=format&fit=crop&w=1200&q=85','place':'Pangong Lake, Ladakh','price':3200,'unit':'per tent / night','type':'Camp','desc':'A lakeside overnight experience. Sample estimate.', 'image':'photo-lake'},
            {'name':'Old Goa Heritage Guesthouse','image_url':'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=1200&q=85','place':'North Goa','price':2200,'unit':'per room / night','type':'Guesthouse','desc':'A relaxed base near cafés and heritage streets. Sample estimate.','image':'photo-coast'},
            {'name':'Backwater Eco Stay','image_url':'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1200&q=85','place':'Alleppey, Kerala','price':2600,'unit':'per room / night','type':'Eco stay','desc':'Quiet stay close to Kerala backwaters. Sample estimate.','image':'photo-forest'},
            {'name':'Pink City Boutique Stay','image_url':'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=85','place':'Jaipur, Rajasthan','price':2400,'unit':'per room / night','type':'Boutique hotel','desc':'A colourful heritage-inspired stay. Sample estimate.','image':'photo-city'},
            {'name':'Rishikesh Riverside Hostel','image_url':'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1200&q=85','place':'Rishikesh, Uttarakhand','price':750,'unit':'per bed / night','type':'Hostel','desc':'Social common areas for solo travellers. Sample estimate.','image':'photo-river'}]},
    'transportation': {
        'title':'Transportation', 'subtitle':'Compare travel modes and add an estimate to your trip budget.', 'category':'Transportation',
        'items':[
            {'name':'Shared SUV from Leh','image_url':'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1200&q=85','place':'Leh → Nubra Valley','price':2800,'unit':'per person return','type':'Shared cab','desc':'A shared road-trip estimate; route and availability must be confirmed.','image':'photo-mountain'},
            {'name':'Airport transfer','image_url':'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=1200&q=85','place':'Leh Airport → Leh town','price':600,'unit':'per vehicle','type':'Cab transfer','desc':'Estimated local transfer fare. Confirm with the provider.','image':'photo-road'},
            {'name':'Sleeper bus','image_url':'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=85','place':'Delhi → Manali','price':1100,'unit':'per person one way','type':'Bus','desc':'Sample fare only; not a live ticket price.','image':'photo-road'},
            {'name':'Scooter rental','image_url':'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1200&q=85','place':'North Goa','price':500,'unit':'per day','type':'Rental','desc':'Sample daily estimate; licence and deposit may be required.','image':'photo-coast'},
            {'name':'Local auto & cab fund','image_url':'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=85','place':'Jaipur city','price':900,'unit':'per day per group','type':'Local transport','desc':'Flexible local travel allowance. Sample estimate.','image':'photo-city'},
            {'name':'Backwater boat transfer','image_url':'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=85','place':'Alleppey','price':1500,'unit':'per group','type':'Boat','desc':'Estimated transfer / short boat ride.','image':'photo-river'}]},
    'activities': {
        'title':'Activities & experiences','subtitle':'Add memorable experiences to your itinerary and shared budget.', 'category':'Activities',
        'items':[
            {'name':'Pangong Lake day trip','image_url':'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=85','place':'Ladakh','price':1200,'unit':'per person','type':'Nature','desc':'Lakeside stops and photography time. Sample estimate.','image':'photo-lake'},
            {'name':'Monastery trail','image_url':'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=85','place':'Leh, Ladakh','price':650,'unit':'per person','type':'Culture','desc':'Visit local monasteries and learn about the region.','image':'photo-mountain'},
            {'name':'Sunset kayaking','image_url':'https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=1200&q=85','place':'North Goa','price':950,'unit':'per person','type':'Water activity','desc':'Estimated guided session; weather dependent.','image':'photo-coast'},
            {'name':'Tea garden walk','image_url':'https://images.unsplash.com/photo-1597318181409-cf64d0b5d8a2?auto=format&fit=crop&w=1200&q=85','place':'Munnar, Kerala','price':500,'unit':'per person','type':'Nature','desc':'A guided walk through scenic tea gardens.','image':'photo-forest'},
            {'name':'Amber Fort & old city','image_url':'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1200&q=85','place':'Jaipur, Rajasthan','price':800,'unit':'per person','type':'Culture','desc':'Heritage sightseeing allowance. Entry fees may vary.','image':'photo-city'},
            {'name':'River rafting','image_url':'https://images.unsplash.com/photo-1530866495561-507c9faab2ed?auto=format&fit=crop&w=1200&q=85','place':'Rishikesh','price':1200,'unit':'per person','type':'Adventure','desc':'Sample estimate; only use licensed operators and check conditions.','image':'photo-river'}]}}

PACKAGES = [
 {'name':'Ladakh High-Altitude Escape','destination':'Ladakh','days':'7 days / 6 nights','price':24999,'style':'Adventure','image':'photo-mountain','description':'Leh, Nubra Valley, Pangong Lake, monasteries and mountain-road views.','includes':['Guesthouse stay estimate','Shared cab transfers','Monastery visits','Pangong day trip'],'itinerary':['Day 1 · Arrive in Leh and acclimatise','Day 2 · Leh local monasteries','Day 3 · Drive to Nubra Valley','Day 4 · Explore Nubra and return','Day 5 · Pangong Lake day trip','Day 6 · Flexible local exploration','Day 7 · Departure']},
 {'name':'Goa Sun & Slow Days','destination':'Goa','days':'4 days / 3 nights','price':11999,'style':'Relaxed','image':'photo-coast','description':'Beach time, cafés, heritage streets and an optional sunset water activity.','includes':['Guesthouse estimate','Local transport allowance','Heritage walk','Sunset activity estimate'],'itinerary':['Day 1 · Check in and beach sunset','Day 2 · North Goa beaches and cafés','Day 3 · Heritage lanes and optional kayaking','Day 4 · Breakfast and departure']},
 {'name':'Kerala Green Getaway','destination':'Kerala','days':'5 days / 4 nights','price':16999,'style':'Nature','image':'photo-forest','description':'Tea gardens, backwaters, green hills and slow local experiences.','includes':['Eco-stay estimate','Local transfers','Tea garden walk','Backwater experience'],'itinerary':['Day 1 · Arrive and transfer','Day 2 · Tea gardens and viewpoints','Day 3 · Scenic drive','Day 4 · Backwater experience','Day 5 · Departure']},
 {'name':'Jaipur Culture Weekend','destination':'Jaipur','days':'3 days / 2 nights','price':7999,'style':'Culture','image':'photo-city','description':'Explore the Pink City, historic forts, local food and colourful bazaars.','includes':['Boutique stay estimate','Local transport allowance','Heritage sightseeing','Food walk allowance'],'itinerary':['Day 1 · Old city and local food','Day 2 · Amber Fort and viewpoints','Day 3 · Markets and departure']},
 {'name':'Rishikesh Adventure Crew','destination':'Rishikesh','days':'3 days / 2 nights','price':8999,'style':'Adventure','image':'photo-river','description':'Riverside downtime, café hopping and an optional guided adventure activity.','includes':['Hostel estimate','Local transfers','Riverside walk','Optional rafting estimate'],'itinerary':['Day 1 · Arrive and riverside evening','Day 2 · Optional rafting and cafés','Day 3 · Local walk and departure']},
 {'name':'Manali Mountain Weekend','destination':'Manali','days':'4 days / 3 nights','price':10999,'style':'Adventure','image':'photo-road','description':'Pine forests, mountain viewpoints, local markets and flexible free time.','includes':['Hostel or guesthouse estimate','Local transport allowance','Nature walk','Local sightseeing'],'itinerary':['Day 1 · Arrive in Manali','Day 2 · Viewpoints and local cafés','Day 3 · Nature walk and free time','Day 4 · Departure']}
]

@app.route('/stays', defaults={'catalog_name': 'stays'})
@app.route('/transportation', defaults={'catalog_name': 'transportation'})
@app.route('/activities', defaults={'catalog_name': 'activities'})
@app.route('/<catalog_name>')
def catalog(catalog_name):
    if catalog_name not in CATALOG:
        abort(404)
    data = CATALOG[catalog_name]
    available_trips = []
    user = current_user()
    if user:
        available_trips.extend(Trip.query.filter_by(creator_id=user.id).order_by(Trip.created_at.desc()).all())
        memberships = Membership.query.filter_by(user_id=user.id, status='accepted').all()
        known_ids = {trip.id for trip in available_trips}
        available_trips.extend(m.trip for m in memberships if m.trip and m.trip.id not in known_ids)
    return render_template('catalog.html', catalog_name=catalog_name, data=data, available_trips=available_trips)

@app.route('/packages')
def packages():
    return render_template('packages.html', packages=PACKAGES)

@app.route('/packages/<int:package_index>/start', methods=['POST'])
@login_required
def start_package(package_index):
    if package_index < 0 or package_index >= len(PACKAGES): abort(404)
    pack = PACKAGES[package_index]
    from datetime import timedelta
    start = date.today() + timedelta(days=30)
    end = start + timedelta(days=max(1, int(pack['days'].split()[0])-1))
    trip = Trip(title=pack['name'], destination=pack['destination'], start_location=current_user().city or 'Your city', start_date=start.isoformat(), end_date=end.isoformat(), budget=pack['price'], description=pack['description'] + ' Package costs are planning estimates, not bookings. You can edit every item after creating the trip.', interests=pack['style']+', sightseeing, photography', max_members=5, creator_id=current_user().id)
    db.session.add(trip); db.session.commit()
    for i, item in enumerate(pack['itinerary']):
        db.session.add(ItineraryItem(trip_id=trip.id, added_by=current_user().id, day=item.split(' · ')[0], title=item.split(' · ',1)[1], time='', notes='Suggested package itinerary — edit to fit your plans.', cost=0))
    for title, category, amount in [(pack['includes'][0], 'Accommodation', round(pack['price']*.30)), (pack['includes'][1], 'Transportation', round(pack['price']*.25)), (pack['includes'][2], 'Activities', round(pack['price']*.15)), (pack['includes'][3], 'Activities', round(pack['price']*.10))]:
        db.session.add(Expense(trip_id=trip.id, added_by=current_user().id, category=category, title=title, amount=amount, details='Package planning estimate — edit or remove as needed.'))
    db.session.commit()
    flash('Package added as your trip! You can edit the dates, itinerary and every estimated cost.', 'success')
    return redirect(url_for('trip_detail', trip_id=trip.id))

@app.route('/catalog/<catalog_name>/<int:item_index>/add', methods=['POST'])
@login_required
def add_catalog_item(catalog_name, item_index):
    if catalog_name not in CATALOG or item_index < 0 or item_index >= len(CATALOG[catalog_name]['items']): abort(404)
    try:
        trip_id = int(request.form.get('trip_id', ''))
    except (TypeError, ValueError):
        flash('Choose a trip before adding this item.', 'error')
        return redirect(url_for('catalog', catalog_name=catalog_name))
    trip = trip_access(trip_id)
    item = CATALOG[catalog_name]['items'][item_index]
    title = request.form.get('title', item['name']).strip()[:160] or item['name']
    try: amount = float(request.form.get('amount', item['price']))
    except ValueError: amount = item['price']
    if amount <= 0 or amount > 100000000:
        flash('Enter a valid amount.', 'error')
    else:
        db.session.add(Expense(trip_id=trip.id, added_by=current_user().id, category=CATALOG[catalog_name]['category'], title=title, amount=amount, details=f"{item['place']} · Editable estimate · {item['unit']}"))
        db.session.commit(); flash(f"{title} added to {trip.title}'s shared budget.", 'success')
    return redirect(url_for('trip_detail', trip_id=trip.id) + '#budget')

@app.route('/buddies/connect/<int:user_id>', methods=['POST'])
@login_required
def connect(user_id):
    me=current_user(); other=db.session.get(User,user_id)
    if not other or other.id==me.id: abort(404)
    existing=Connection.query.filter(or_(db.and_(Connection.sender_id==me.id,Connection.receiver_id==other.id),db.and_(Connection.sender_id==other.id,Connection.receiver_id==me.id))).first()
    if existing: flash('A connection request already exists.', 'info')
    else: db.session.add(Connection(sender_id=me.id,receiver_id=other.id)); db.session.commit(); flash('Connection request sent.', 'success')
    return redirect(url_for('buddies'))

@app.route('/connections')
@login_required
def connections():
    me=current_user(); incoming=Connection.query.filter_by(receiver_id=me.id,status='pending').all()
    outgoing=Connection.query.filter_by(sender_id=me.id,status='pending').all()
    accepted=Connection.query.filter(or_(db.and_(Connection.sender_id==me.id,Connection.status=='accepted'),db.and_(Connection.receiver_id==me.id,Connection.status=='accepted'))).all()
    return render_template('connections.html',incoming=incoming,outgoing=outgoing,accepted=accepted,me=me)

@app.route('/connections/<int:conn_id>/<action>', methods=['POST'])
@login_required
def connection_action(conn_id,action):
    c=db.session.get(Connection,conn_id)
    if not c or c.receiver_id!=current_user().id or c.status!='pending' or action not in ('accept','reject'): abort(403)
    c.status='accepted' if action=='accept' else 'rejected'; db.session.commit(); flash('Connection request updated.', 'success'); return redirect(url_for('connections'))

@app.route('/messages', defaults={'other_id': None})
@app.route('/messages/<int:other_id>')
@login_required
def messages(other_id):
    me=current_user(); people=[]
    accepted=Connection.query.filter(or_(db.and_(Connection.sender_id==me.id,Connection.status=='accepted'),db.and_(Connection.receiver_id==me.id,Connection.status=='accepted'))).all()
    ids=set()
    for c in accepted: ids.add(c.receiver_id if c.sender_id==me.id else c.sender_id)
    shared=Membership.query.filter_by(user_id=me.id,status='accepted').all()
    for m in shared:
        trip=m.trip
        ids.update(x.user_id for x in trip.memberships if x.status=='accepted' and x.user_id!=me.id)
        ids.add(trip.creator_id)
    ids.discard(me.id)
    people=User.query.filter(User.id.in_(ids)).all() if ids else []
    other=db.session.get(User,other_id) if other_id else (people[0] if people else None)
    if other and other.id not in ids: abort(403)
    chat=[]
    if other:
        chat=Message.query.filter(or_(db.and_(Message.sender_id==me.id,Message.receiver_id==other.id),db.and_(Message.sender_id==other.id,Message.receiver_id==me.id))).order_by(Message.created_at.asc()).all()
    return render_template('messages.html',people=people,other=other,chat=chat,me=me)

@app.route('/api/v1/messages/<int:other_id>', methods=['POST'])
@login_required
def api_send_message(other_id):
    me=current_user(); other=db.session.get(User,other_id)
    if not other or other.id==me.id: return jsonify(error='Invalid recipient.'),400
    connected=Connection.query.filter(or_(db.and_(Connection.sender_id==me.id,Connection.receiver_id==other.id),db.and_(Connection.sender_id==other.id,Connection.receiver_id==me.id))).filter_by(status='accepted').first()
    shared=False
    for membership in Membership.query.filter_by(user_id=me.id,status='accepted').all():
        if membership.trip.creator_id==other.id or Membership.query.filter_by(trip_id=membership.trip_id,user_id=other.id,status='accepted').first(): shared=True; break
    if not connected and not shared: return jsonify(error='Connect first or share an accepted trip to message.'),403
    body=(request.json or {}).get('body','').strip()
    if not body or len(body)>2000: return jsonify(error='Message must be between 1 and 2000 characters.'),400
    msg=Message(sender_id=me.id,receiver_id=other.id,body=body); db.session.add(msg); db.session.commit()
    return jsonify(id=msg.id,body=msg.body,sender_id=me.id,created_at=msg.created_at.isoformat()),201

@app.route('/api/v1/trips/<int:trip_id>/budget')
def api_budget(trip_id):
    trip=db.session.get(Trip,trip_id)
    if not trip: return jsonify(error='Trip not found.'),404
    cats=expense_totals(trip); total=sum(cats.values())
    return jsonify(trip_id=trip.id,categories=cats,total=total,per_person=round(total/(1+len([m for m in trip.memberships if m.status=='accepted'])),2))

@app.errorhandler(403)
def forbidden(_): return render_template('error.html', code=403, message='You do not have permission to view this page.'),403
@app.errorhandler(404)
def not_found(_): return render_template('error.html', code=404, message='We could not find that page.'),404

with app.app_context():
    db.create_all()
    # Add demo records only when missing. These are ordinary database rows, not hardcoded UI cards.
    demo_people = [
        ('Aarav Mehta','aarav@example.com','Delhi','Mountains, local food and long road trips.','Hiking,Photography,Food','Adventure',18000),
        ('Sana Kapoor','sana@example.com','Jaipur','Slow travel, culture and beautiful sunsets.','Culture,Photography,Food','Relaxed',15000),
        ('Riya Sharma','riya@example.com','Noida','Weekend explorer who loves cafes and hidden streets.','Food,Photography,Culture','Flexible',12000),
        ('Kabir Singh','kabir@example.com','Lucknow','Here for road trips, hikes and spontaneous plans.','Hiking,Adventure,Nature','Adventure',22000),
        ('Meera Nair','meera@example.com','Kochi','Nature, beaches, books and slow mornings.','Nature,Beaches,Photography','Relaxed',16000),
        ('Dev Malhotra','dev@example.com','Chandigarh','Budget-conscious traveller and mountain lover.','Hiking,Camping,Adventure','Budget',14000),
        ('Ananya Verma','ananya@example.com','Delhi','I plan the basics and leave room for surprises.','Culture,Food,Shopping','Flexible',18000),
        ('Ishaan Rao','ishaan@example.com','Pune','Photographer looking for scenic routes.','Photography,Nature,Road trips','Adventure',26000),
        ('Zoya Khan','zoya@example.com','Mumbai','Beaches, music, art walks and good food.','Beaches,Music,Food','Relaxed',20000),
        ('Arjun Das','arjun@example.com','Kolkata','History buff who loves meeting new people.','Culture,History,Food','Culture',13000),
        ('Tanya Gupta','tanya@example.com','Ghaziabad','Short trips, cute stays and travel reels.','Photography,Shopping,Cafes','Flexible',10000),
        ('Vihaan Joshi','vihaan@example.com','Indore','Adventure sports and early morning hikes.','Adventure,Hiking,Nature','Adventure',24000),
        ('Naina Roy','naina@example.com','Bengaluru','Remote worker collecting weekend escapes.','Nature,Cafes,Photography','Budget',17000),
        ('Rehan Ali','rehan@example.com','Hyderabad','Food trails and local culture first.','Food,Culture,History','Culture',15000),
        ('Pooja Menon','pooja@example.com','Chennai','Ocean person, wildlife fan and planner.','Beaches,Nature,Wildlife','Relaxed',19000),
        ('Aditya Jain','aditya@example.com','Agra','Looking for friendly groups and new routes.','Road trips,Adventure,Food','Budget',11000),
    ]
    people = {}
    for name,email,city,bio,interests,style,budget in demo_people:
        user = User.query.filter_by(email=email).first()
        if not user:
            user = User(name=name,email=email,password_hash=generate_password_hash('Travel123!'),city=city,bio=bio,interests=interests,travel_style=style,budget=budget)
            db.session.add(user); db.session.flush()
        people[email] = user
    db.session.commit()
    trip_specs = [
      ('Himalayan Escape','Ladakh','Delhi','2027-06-10','2027-06-17',25000,'High mountain passes, blue lakes, monasteries and unforgettable road-trip views.','Hiking,Photography,Adventure','aarav@example.com',5),
      ('Goa Beach & Cafe Crawl','Goa','Mumbai','2027-01-15','2027-01-19',14000,'Beach sunsets, local cafes, heritage lanes and relaxed mornings.','Beaches,Food,Photography','zoya@example.com',6),
      ('Kerala Backwater Slow Trip','Kerala','Kochi','2027-02-08','2027-02-13',18500,'Green hills, backwaters, local food and a little time to slow down.','Nature,Food,Photography','meera@example.com',5),
      ('Jaipur Heritage Weekend','Jaipur','Delhi','2027-01-22','2027-01-25',9000,'Forts, bazaars, heritage architecture and local food stops.','Culture,History,Food','sana@example.com',5),
      ('Rishikesh Adventure Days','Rishikesh','Ghaziabad','2027-03-12','2027-03-15',10500,'Riverside cafes, forest walks and optional guided rafting.','Adventure,Nature,Hiking','kabir@example.com',6),
      ('Manali Snow & Trails','Manali','Chandigarh','2027-02-18','2027-02-22',16000,'Pine forests, mountain views and flexible outdoor days.','Hiking,Photography,Adventure','dev@example.com',5),
      ('Udaipur Lakeside Escape','Udaipur','Jaipur','2027-02-04','2027-02-07',11500,'Lake views, old-city walks, art and evening boat rides.','Culture,Photography,Food','ananya@example.com',4),
      ('Meghalaya Cloud Trails','Shillong','Guwahati','2027-04-10','2027-04-16',23000,'Waterfalls, living root bridges and misty green landscapes.','Nature,Hiking,Photography','ishaan@example.com',5),
      ('Mumbai Arts & Food Weekend','Mumbai','Pune','2027-01-29','2027-02-01',12500,'Street food, galleries, seaside walks and city photography.','Food,Art,Photography','riya@example.com',6),
      ('Andaman Blue Escape','Andaman','Port Blair','2027-03-05','2027-03-10',28500,'Clear water, island time, snorkelling and relaxed beach days.','Beaches,Nature,Adventure','pooja@example.com',5),
      ('Varanasi Culture Walk','Varanasi','Lucknow','2027-02-26','2027-03-01',8500,'A thoughtful trip for riverfront walks, food and local heritage.','Culture,History,Food','arjun@example.com',4),
      ('Coorg Green Weekend','Coorg','Bengaluru','2027-04-02','2027-04-05',13000,'Coffee estates, forest roads and slow mornings in the hills.','Nature,Food,Road trips','naina@example.com',5),
      ('Spiti Valley Road Trip','Spiti Valley','Chandigarh','2027-06-20','2027-06-27',27000,'Remote villages, mountain roads and starry skies.','Road trips,Adventure,Photography','vihaan@example.com',5),
      ('Agra & Fatehpur Sikri','Agra','Delhi','2027-01-08','2027-01-10',6500,'Architecture, history, local breakfast spots and sunrise views.','History,Culture,Photography','aditya@example.com',6),
      ('Pondicherry Slow Living','Pondicherry','Chennai','2027-03-19','2027-03-23',15500,'Coastal cycling, colourful streets, cafes and beach time.','Beaches,Cafes,Photography','tanya@example.com',5),
    ]
    for title,dest,origin,start,end,budget,desc,interests,email,cap in trip_specs:
        trip = Trip.query.filter_by(title=title,creator_id=people[email].id).first()
        if not trip:
            trip = Trip(title=title,destination=dest,start_location=origin,start_date=start,end_date=end,budget=budget,description=desc,interests=interests,max_members=cap,creator_id=people[email].id,status='open')
            db.session.add(trip); db.session.flush()
            # Starter itinerary and cost estimates make trip details useful immediately.
            db.session.add_all([
              ItineraryItem(trip_id=trip.id,added_by=trip.creator_id,day='Day 1',title=f'Arrive in {dest} and settle in',notes='Suggested plan — edit to suit the group.',cost=0),
              ItineraryItem(trip_id=trip.id,added_by=trip.creator_id,day='Day 2',title=f'Explore local highlights in {dest}',notes='Group can choose the exact stops together.',cost=0),
              Expense(trip_id=trip.id,added_by=trip.creator_id,category='Accommodation',title='Stay estimate',amount=round(budget*.28),details='Illustrative planning estimate; not a booking.'),
              Expense(trip_id=trip.id,added_by=trip.creator_id,category='Transportation',title='Local transport estimate',amount=round(budget*.24),details='Illustrative planning estimate; not a live fare.'),
              Expense(trip_id=trip.id,added_by=trip.creator_id,category='Activities',title='Sightseeing and activities estimate',amount=round(budget*.16),details='Illustrative planning estimate; editable by trip members.'),
            ])
    db.session.commit()

if __name__=='__main__':
    app.run(debug=os.getenv('FLASK_DEBUG','0')=='1')
