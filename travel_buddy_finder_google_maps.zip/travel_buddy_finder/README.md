# Travel Buddy Finder

**Find the right person. Plan the right trip.**

A responsive Flask + SQLAlchemy travel-buddy website with account login, buddy profiles, trip discovery, join requests, shared budgets, editable expenses, itinerary planning, stay/transport/activity catalogs, and ready-made trip packages.

## Features

- Individual registration and login with hashed passwords.
- Seeded demo profiles and trips stored as normal database records (not frontend-only cards).
- Explore trips and find buddies; filters are database-backed.
- Create trips and request to join another traveller's trip.
- Shared trip budget with accommodation, transportation, activities, food and other categories.
- Edit or remove expenses; changes update the shared budget automatically.
- Day-by-day itinerary and starter itinerary for demo trips.
- Browse stays, transportation and activities; select a trip and edit the estimate before adding it to that trip's budget.
- Ready-made packages for Ladakh, Goa, Kerala, Jaipur, Rishikesh and Manali. Starting a package creates an editable trip with itinerary and cost estimates.
- Direct messages for accepted connections or people sharing an accepted trip.
- Google Maps page for destination maps, place/attraction search, and Google Maps directions with route distance and estimated travel time.
- Responsive layout with destination photography. Internet is required for maps, remote photos and Bootstrap/font CDNs.

All catalog/package prices are illustrative planning estimates, not live prices, availability or bookings.

## Requirements

- Python 3.10+
- pip

## Run locally (Windows PowerShell)

Open this project folder in VS Code. The `app.py` and `requirements.txt` files are in the project root.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py app.py
```

If `py` is unavailable, install Python from https://www.python.org/downloads/windows/ and select **Add python.exe to PATH**, then reopen VS Code.

Open http://127.0.0.1:5000.

## Demo accounts

Demo password for seeded users: `Travel123!`

- `aarav@example.com`
- `sana@example.com`
- `riya@example.com`
- `kabir@example.com`
- `meera@example.com`
- `dev@example.com`
- `ananya@example.com`
- `ishaan@example.com`
- `zoya@example.com`
- `arjun@example.com`
- `tanya@example.com`
- `vihaan@example.com`
- `naina@example.com`
- `rehan@example.com`
- `pooja@example.com`
- `aditya@example.com`

Demo records are added only if missing. The database is stored in `travel_buddy_finder.db` in the project folder. For a clean reset, stop the server and delete that database file; the app will recreate it on next start.

## Database configuration

SQLite is the default for straightforward student-project setup. To use another SQLAlchemy-supported database, set `DATABASE_URL` before starting the app. Set a strong `SECRET_KEY` for deployment. Do not deploy with the development secret.

## Main pages

- `/` landing page
- `/register`, `/login`
- `/maps` destination maps, place search and directions
- `/trips` explore trips
- `/trips/create` create trip (login required)
- `/buddies` discover people (login required)
- `/packages` browse ready-made packages
- `/stays`, `/transportation`, `/activities` catalogs
- `/trips/<id>` trip workspace, budget and itinerary
- `/profile`, `/connections`, `/messages`

## Notes

This is a college-project demo. Stay/transport/activity prices are sample estimates and no ticket or hotel booking occurs. The messaging feature uses regular requests rather than push-based real-time chat. Before public deployment, configure a production secret, CSRF protection, rate limiting, secure cookies, and proper migrations/production database settings.


## Updated catalogue and photography

The Stays, Transportation, and Activities pages have explicit routes and each item has its own relevant photo URL. Use the selector on each card to choose a trip and adjust the estimate before adding it to the trip budget. Trip cards use destination-matched imagery. Buddy cards use human portraits for the seeded demo accounts; new accounts use an initials avatar unless a profile photo feature is configured. Photos are loaded from external image hosts and therefore require an internet connection.

## Latest fixes (11 October 2026)
- The Stays, Transportation, and Activities links have explicit working routes.
- Adding an item now uses a normal POST form that sends the selected trip ID, instead of constructing the request URL in inline JavaScript.
- Each catalogue item has its own image URL; trip cards rotate through destination-relevant photo options to reduce repetition.
- External photos require an internet connection. Catalogue prices are sample planning estimates, not live availability or bookings.

On Windows, from this project folder run:
```powershell
py -m pip install -r requirements.txt
py app.py
```
Then open `http://127.0.0.1:5000` in your browser.


## Google Maps feature

Open **Maps & routes** in the navigation to view a destination map, search places and attractions, and open directions from a starting location to a destination. The app uses Google Maps search/embed URLs, so no API key is needed for this basic integration. Google Maps opens externally for current route choices, distance, estimated travel time, traffic and turn-by-turn navigation. A future fully embedded Places/Routes API integration may require a Google Cloud project, enabled APIs, an API key and billing.
